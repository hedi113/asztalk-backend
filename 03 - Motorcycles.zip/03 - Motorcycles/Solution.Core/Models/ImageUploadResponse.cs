﻿namespace Solution.Core.Models;

public class ImageUploadResponse
{
    public string Id { get; set; }

    public string WebContentLink { get; set; }
}
