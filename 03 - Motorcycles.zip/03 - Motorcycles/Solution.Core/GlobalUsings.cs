﻿global using ErrorOr;
global using Google.Apis.Auth.OAuth2;
global using Solution.Database.Entities;
global using System.Text.Json.Serialization;
global using Solution.Core.Models;
global using CommunityToolkit.Mvvm.ComponentModel;
global using Microsoft.Maui.Storage;