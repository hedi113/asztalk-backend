﻿namespace Solution.DesktopApp.ViewModels;

public class MainViewModel(AppDbContext dbContext)
{
}
