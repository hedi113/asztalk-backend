﻿global using FluentValidation;
global using Solution.Core.Models;