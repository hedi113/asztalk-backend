﻿global using Microsoft.AspNetCore.Components;
global using Microsoft.AspNetCore.Components.Web;
global using Microsoft.Extensions.Logging;
global using Microsoft.Playwright;
global using System.Diagnostics.CodeAnalysis;