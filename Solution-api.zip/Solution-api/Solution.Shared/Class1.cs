﻿namespace Solution.Shared
{
    public class Class1
    {

    }
}
