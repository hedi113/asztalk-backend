﻿namespace Solution.WebAPI.Controllers
{
    public class SecurityController
    {
    }
}
