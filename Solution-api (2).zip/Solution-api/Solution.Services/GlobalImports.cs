﻿global using Microsoft.AspNetCore.Identity.Data;
global using Solution.Domain.Models.Requests.Security;
global using Solution.Domain.Models.Responses;
global using ErrorOr;
