﻿global using Microsoft.AspNetCore.Identity;
global using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore;
global using Solution.Domain.Database.Builders;
global using Solution.Domain.Database.Entities;